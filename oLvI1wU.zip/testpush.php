<?php

if (APP_ENV !== 'dev') {
    die('improper environment');
}

if (APP_ENV == 'live') {

} else {
    echo APP_ENV;
    $cert = '../certs/dev.pem';
    $passphras = 'sUIuRBjCWCg1DnYEpnFwZJF8C4';
    $endpoint = 'ssl://gateway.sandbox.push.apple.com:2195';
}

// Put your device token here (without spaces):
$deviceToken = 'd5a8a8c06e88b2c803fa41669012f1eb9c377401';


$message = 'this is a test';
$url = 'http://www.google.com';

////////////////////////////////////////////////////////////////////////////////

$ctx = stream_context_create();
stream_context_set_option($ctx, 'ssl', 'local_cert', $cert);
stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase);

die();

// Open a connection to the APNS server
$fp = stream_socket_client(
  $endpoint, $err,
  $errstr, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $ctx);

if (!$fp)
  exit("Failed to connect: $err $errstr" . PHP_EOL);

echo 'Connected to APNS' . PHP_EOL;

// Create the payload body
$body['aps'] = array(
  'alert' => $message,
  'sound' => 'default',
  'link_url' => $url,
  );

// Encode the payload as JSON
$payload = json_encode($body);

// Build the binary notification
$msg = chr(0) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;

// Send it to the server
$result = fwrite($fp, $msg, strlen($msg));

if (!$result)
  echo 'Message not delivered' . PHP_EOL;
else
  echo 'Message successfully delivered' . PHP_EOL;

// Close the connection to the server
fclose($fp);
