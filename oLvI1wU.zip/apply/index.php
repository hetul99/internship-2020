<?php
header('Location: https://docs.google.com/forms/d/e/1FAIpQLSff-ccoV1dxbw8tFLcLS7Xl6nrz8fVX-BRzYLMNC0iwmAXlHQ/viewform');
