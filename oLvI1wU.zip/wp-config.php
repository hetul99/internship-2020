<?php

use Dotenv\Dotenv;

include(ABSPATH.'/wp-content/plugins/wf/vendor/autoload.php');

$dotenv = new Dotenv(ABSPATH.'../');
$dotenv->load();

/** Enable W3 Total Cache */
define('WP_CACHE', true); // Added by W3 Total Cache



/** Enable W3 Total Cache Edge Mode */
define('W3TC_EDGE_MODE', true); // Added by W3 Total Cache

//define('COOKIE_DOMAIN', 'www.watchflippers.com'); // Added by W3 Total Cache
// this breaks the whole thing on testing, yo.
define('COOKIE_DOMAIN', $_SERVER['SERVER_NAME']);



/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

/** The name of the database for WordPress */
define('DB_NAME', env("DB_NAME"));

/** MySQL database username */
define('DB_USER', env("DB_USER"));

/** MySQL database password */
define('DB_PASSWORD', env("DB_PASS"));

/** MySQL hostname */
// define('DB_HOST', $_SERVER['RDS_HOSTNAME'] . ':3306');
define('DB_HOST', env("DB_HOST"));

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', env("DB_CHARSET", 'utf8'));

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', env("DB_COLLATE", ''));

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */

define('WP_DEBUG', env("WP_DEBUG", false));
define('WP_DEBUG_LOG', env("WP_DEBUG_LOG", false));
define('WP_DEBUG_DISPLAY', env("WP_DEBUG_DISPLAY", false));

/*
    Begin some APP specific configuration
 */

/** The name of the environment we are in */
define('APP_ENV', env('APP_ENV', 'production'));
define('FB_POSTING_ENABLED', (bool)env('FB_POSTING_ENABLED', false));
define('NEW_POST_ADVANCED_FIELDS_ENABLED', (bool)env('NEW_POST_ADVANCED_FIELDS_ENABLED', false));
define('SEARCH_BRANDS_ENABLED', (bool)env('SEARCH_BRANDS_ENABLED', false));
define('AIRSHIP_ENABLED', (bool)env('AIRSHIP_ENABLED', false));
define("FORCE_WWW", env("FORCE_WWW", true));

// S3, if it exists
if (env("APP_S3BUCKET", false) && env("APP_S3KEY", false) && env("APP_S3SECRET")) {
    define('S3_UPLOADS_BUCKET', env("APP_S3BUCKET"));
    define('S3_UPLOADS_KEY', env("APP_S3KEY"));
    define('S3_UPLOADS_SECRET', env("APP_S3SECRET"));
}
/** CS Custom S3 Code EOF */

/**
 * WP CRON
 */
define('DISABLE_WP_CRON', env("WPCRON_DISABLE", false)); //running WP cron


/**ZZ
 * SSL Settings from ENV *
 * Set in vhost
 */
$protocol = "http://";
/**
 * Check if Elastic Load Balancer forwarded an HTTPS header
 * modified from http://codex.wordpress.org/Function_Reference/is_ssl
 */
if ($_SERVER["ENABLE_SSL"] || (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] == 'https')) {
    $_SERVER['HTTPS'] = 'on';
    $protocol = "https://";

    /**
     * SET/FORCE WP SSL
     * modified from http://prosauce.org/blog/2010/8/5/enable-complete-support-for-ssl-on-wordpress.html
     */

    define('FORCE_SSL_ADMIN', true);
} else {
    define('FORCE_SSL_ADMIN', false);
}

if (FORCE_WWW && strpos($_SERVER["SERVER_NAME"], 'www.') !== 0) {
    header("Location: {$protocol}www.{$_SERVER['SERVER_NAME']}");
    die();
}

if (!defined('WP_SITEURL')) {
    define('WP_SITEURL', $protocol.$_SERVER["SERVER_NAME"]);
}
define("WP_CONTENT_URL", WP_SITEURL. "/wp-content");
define("WP_HOME", WP_SITEURL);

define('SITE_NAME', env("SITE_NAME", false));
define('SITE_DOMAIN', $_SERVER["SERVER_NAME"]);

/**
 * Mem Cache Settings from ENV
 * Modified from  http://blog.celingest.com/en/2013/07/09/tutorial-using-elasticache-with-wordpress/
 * Set in vhost
 */

if (!defined('WP_CACHE')
   && env("APP_MEM_CACHE", false)
   && env("APP_MEM_CACHE", false)
) {
    $envMemCache = unserialize(env("APP_MEM_CACHE"));
    if (is_array($envMemCache) && !empty($envMemCache["default"])  && is_array($envMemCache["default"])) {

        /**
         * Provide a serialize array of cache servers formatted in httpd.conf
         * $memcached_servers = array(
         *   'default' => array(
         *        'elasticache.zwcxmw.001.use1.cache.amazonaws.com:11211'     //We can add more nodes by using commas
         *   )
         * );
         *
         * We have to check that WordPress is configured to use the cache
         * looking for the following line and assuring the value is 'true'. If there isn't
         * we must create it:
         **/

        $memcached_servers = $envMemCache;
        define('WP_CACHE', true);
    }
}

/**
 * take care of different tag ids in different evironments
 */
define('WFT_REFERENCE_ID', env('WFT_REFERENCE_ID', null));

/** Clean-up */
unset($protocol, $envMemCache);



define('FS_METHOD', 'direct');

define('W3TC_ENTERPRISE', true);

if (defined('WPDB_PATH')) {
    require_once(WPDB_PATH);
} else {
    require_once(ABSPATH . '/wp-includes/wp-db.php');
}

class W3_Db_Driver extends wpdb
{
    function _real_escape ($string)
    {
        return addslashes($string);
    }
}


/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');


/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', '[q*k?8mw)L8DpF4ozG,>-bpZr{WOdiSwc*~}?|U]L4bp5+{&529R?rx![w(F/oi$');
define('SECURE_AUTH_KEY', '[^HAsFjA^9UIq4.)3C:kh(I-cQE<S?_BiC`!FxE9h <@-]y<5|:pH+U(-kk+#3Kp');
define('LOGGED_IN_KEY', '{Rw>qj-Sook/!fYOD}8.N!aq:~ZZU()R SEGo4R;UFj}%,r3ucWjG7V|DE|.moOO');
define('NONCE_KEY', 'xGV&!kB?u7=/nPIyFWAJF%bWhrd#{e+W>2{go!,f; 5l][B+SR-@cc%4U3@s+!#k');
define('AUTH_SALT', '-?)?3*%%piFk0<;`U-%EMI|/Uv3r-(A%%$W(};6k|+-9zIe=jLnF|%h<]KhG2(;3');
define('SECURE_AUTH_SALT', '?a7308V@3DeZzY.TR$kVv^6,$+^bP04+m.B)8`P[Is@KbHRb9X0-#y`O!7s]S|Pg');
define('LOGGED_IN_SALT', ']emn}$8FD|wgfw(K+T/CyDcw[jh~6+yA-#`-E/4[o*~h+#:3WF%N8=WSs3<Oe*/F');
define('NONCE_SALT', ';9M4>A]_-P1(5E[2$*/+2B,U/7|/$=/v)oqC]I@z(n-p*FYB%angvrW,f}-/uQRP');
/**#@-*/


/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if (!defined('ABSPATH')) {
    define('ABSPATH', dirname(__FILE__) . '/');
}

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

/** Custom local cache update  */
if (file_exists(ABSPATH . "wp-cache-local-update.php")) {
    require_once(ABSPATH . "wp-cache-local-update.php");
}
