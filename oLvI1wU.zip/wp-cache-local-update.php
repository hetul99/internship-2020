<?php
/**
 * @author Crimsonshift LLC.
 * @copyright 2015
 *
 * Date: 3/12/2015
 * Time: 5:46 PM
 *
 * Local wp-config.php settings and custom setup if required.  Add to .gitignore
 * if multiple environments are used
 */

if( isset($_SERVER['HTTPS']) &&  $_SERVER['HTTPS'] == 'on' ): wp_cache_set("siteurl_secure", WP_SITEURL, "options"); endif;
wp_cache_set("home", WP_SITEURL, "options");
wp_cache_set("siteurl", WP_SITEURL, "options");